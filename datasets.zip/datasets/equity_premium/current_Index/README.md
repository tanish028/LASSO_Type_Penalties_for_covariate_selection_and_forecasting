# current_Index

The "current, Index-based premium" specification uses the SAME file as "current_CRSP":
`../current_CRSP/PredictorData_current.xlsx`.  The two specifications differ only in how the equity premium is built from that file
(CRSP_SPvw return vs. the Index/D12 return); see `../../metadata/transformations.md`.  The file is stored once to avoid an unnecessary duplicate.
