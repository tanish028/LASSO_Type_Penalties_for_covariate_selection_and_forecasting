# Transformations applied by the code (the files themselves are unmodified)

## Equity premium (code: `wladalasso/equity.py :: load_goyal_welch`)
Annual sheet. Let I = Index, D12 = 12-month dividends, E12 = 12-month earnings, Rfree = risk-free return (simple decimal).
* Excess return (log premium), `log_premium=True`: `log(1 + R_t) - log(1 + Rfree_t)` with
  * `premium_source='crsp'`:  R_t = CRSP_SPvw_t
  * `premium_source='index'`: R_t = (I_t + D12_t) / I_{t-1} - 1   (the documented Welch-Goyal construction)
  * `log_premium=False` (spec B): R_t - Rfree_t
* Predictors (14): d/p = log D12 - log I; d/y = log D12 - log I_{t-1}; e/p = log E12 - log I; d/e = log D12 - log E12; svar; b/m; ntis; tbl; lty; ltr;
  tms = lty - tbl; dfy = BAA - AAA; dfr = corpr - ltr; infl.
* Sample cut to 1927-2005 BEFORE differencing; predictors are first-differenced (`diff_predictors=True`); the premium is kept in levels (spec A, primary).
  Spec C/D additionally difference the premium (`diff_target=True`); spec D also puts lags of the premium among the candidates.
* Rows with missing values after differencing are dropped.
* Forecast of year t: predictors of year t-1 (lag-1 design matrix), data before t only. Benchmark: expanding historical mean.
* The published Table X is not reproduced by these constructions; that discrepancy is unresolved and is preserved.

## FRED-MD (code: `wladalasso/fred.py`)
* t-codes in the first data row: 1 level, 2 diff, 3 second diff, 4 log, 5 log-diff, 6 log second-diff, 7 diff of growth rate.
* Outliers: values more than 10 IQR from the expanding median (statistics from past data only, min 120 obs) are set missing.
* Sample from 1960-03; series with > 5% missing dropped; remaining gaps forward- then back-filled.
* Target: dpi_t = pi_t - pi_{t-1}, pi_t = 1200 * dlog(CPIAUCSL_t). Candidates: all other transformed series x L = 12 lags.

## Real-time inflation (code: `wladalasso/inflation.py`)
* No transformation of the file's series is applied: the replication readme states they are already transformed to stationarity.
* Real commodity-price inflation: nominal OIL, RAW, FOOD (log first differences) minus PCE inflation of the SAME vintage (assumption: PCE rather than GDP deflator).
* Information set for target quarter tau: vintage whose last observation is tau-1.
* Dependent variable: change in PCE inflation (`target_transform='diff'`, default) or PCE inflation (`'level'`); forecasts and errors are reported for PCE inflation.
