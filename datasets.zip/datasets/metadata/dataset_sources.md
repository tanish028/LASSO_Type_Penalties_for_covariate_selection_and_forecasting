# Dataset sources

All files are REAL data files, copied unchanged (byte-identical, SHA-256 in `dataset_inventory.md`). No synthetic or simulated data are included.
"Download date": the project owner supplied these files in the working session on 2026-11-04; the original download dates are **not recorded** and are therefore not claimed here.
Source URLs below are the publishers' public pages as known to the author of this package; they were not re-verified when the package was assembled (no network access to those sites from the build environment).

## 1. Goyal-Welch equity-premium predictors
* **Original 2005 vintage** - `equity_premium/original_2005_vintage/PredictorData_2005_original.xls`
  Excel 97-2003 workbook, sheets Monthly / Quarterly / Annual. Annual sheet: 135 rows x 21 columns, years 1871-2005.
  File properties record a last-saved date of 2007-03-26 (the 2007 distribution of the data underlying Welch & Goyal 2008); it is therefore the 2005-vintage data, not necessarily the exact file used by Konzen & Ziegelmann (2016).
  Source: Amit Goyal's data page (Welch & Goyal 2008, Review of Financial Studies).
* **Current file** - `equity_premium/current_CRSP/PredictorData_current.xlsx`
  Excel workbook, sheets Monthly / Quarterly / Annual. Annual sheet: 155 rows x 21 columns, years 1871-2025.
  Same source, later release (values for overlapping years differ from the original for several series, e.g. D12, Rfree, CRSP_SPvw, svar, ntis, infl; see the earlier-study report).
  Used for TWO specifications that differ only in the premium construction: `current_CRSP` (CRSP_SPvw) and `current_Index` (Index and D12). The file is stored once.

## 2. FRED-MD
* `FRED_MD/current.csv` - McCracken & Ng (2016), "FRED-MD: A Monthly Database for Macroeconomic Research", Journal of Business & Economic Statistics. Source: Federal Reserve Bank of St. Louis FRED-MD page.
  806 rows x 127 columns in the file as supplied (first data row = t-codes "Transform:"; first date 1/1/1959, last row 1/1/2026). Vintage: the file labelled `current` as supplied (the earlier study treated it as the 2026-01 vintage; the last complete month used is 2025-09 - the later rows have missing values).
* `FRED_MD/FRED-MD_updated_appendix.csv` - variable descriptions (documentation only; encoded in Windows-1252, not read by the code).

## 3. Real-time quarterly inflation
* `inflation/dataJBES.xlsx` - replication data of Groen, Paap & Ravazzolo (2013), "Real-time inflation forecasting in a changing world", Journal of Business & Economic Statistics 31(1); obtained from the journal's online supplement (file `ubes_a_727718_sup_28645919.zip` -> `dataJBES.zip`). Dated 2012-08-20 inside the archive.
  Sheets: GDP, PCE, ROUTP, RCONS, RINVR, PIMP, UNEMP, NFPR, HSTS, M2, OIL_FOOD_RAW, YL-TS-CS, MS. Vintage sheets have 206 quarters x 127 vintages; vintage columns run from P80Q1 to P11Q3, quarters 1960:Q1 to 2011:Q2. Vintage PyyQq ends at quarter q-1.
* `inflation/Readme_dataJBES.rtf`, `inflation/Supplement_GPR2013.pdf` - documentation shipped with the replication file.

## Not found / not included (see also `dataset_inventory.md`)
* The unobserved-components (UC-MA, Chan 2013) benchmark forecasts of the paper's Table XI: no data or code available.
* The exact evaluation dates and the "truth" vintage used by Konzen & Ziegelmann (2016) for Table XI: not stated in the paper; the code uses documented, configurable assumptions.
