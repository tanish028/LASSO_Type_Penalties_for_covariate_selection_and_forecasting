# Dataset inventory

Generated from the packaged files. Every file listed is in `datasets.zip`; every file in the zip is listed (this file included).

| Path (inside `datasets/`) | Bytes | SHA-256 | Role |
|---|---|---|---|
| `equity_premium/original_2005_vintage/PredictorData_2005_original.xls` | 751,104 | `7917e2627d1daeb9...` | Goyal-Welch predictors, ORIGINAL 2005 release (data end 2005) |
| `equity_premium/current_CRSP/PredictorData_current.xlsx` | 485,064 | `8d210b779442a5a9...` | Goyal-Welch predictors, CURRENT file (data to 2025); used for both current specifications |
| `FRED_MD/current.csv` | 663,349 | `618fa325fdf4e2d8...` | FRED-MD monthly panel (McCracken-Ng), current vintage as supplied |
| `FRED_MD/FRED-MD_updated_appendix.csv` | 9,049 | `2c445e8918c61500...` | FRED-MD series description appendix (documentation only) |
| `inflation/dataJBES.xlsx` | 1,202,711 | `867be5abe6013162...` | Real-time quarterly inflation data, Groen-Paap-Ravazzolo (2013) replication file |
| `inflation/Readme_dataJBES.rtf` | 1,076 | `a547bd7113cfe08a...` | Readme shipped with dataJBES.xlsx |
| `inflation/Supplement_GPR2013.pdf` | 954,315 | `82cc857484842cc5...` | Online supplement of Groen-Paap-Ravazzolo (2013) (Table B.1: series and transformations) |
| `equity_premium/current_Index/README.md` | 382 | `9e7c97d706cbcd9b...` | Pointer (documentation): second current specification reuses the current_CRSP file |
| `metadata/dataset_sources.md` | 3,431 | `(self-describing...` | Sources and provenance |
| `metadata/transformations.md` | 2,473 | `(self-describing...` | Transformations |

Full SHA-256 values:

* `equity_premium/original_2005_vintage/PredictorData_2005_original.xls` 7917e2627d1daeb917bc3460ca9ad23be1d109c6b0e5370dbc92cecf3d16e20d
* `equity_premium/current_CRSP/PredictorData_current.xlsx` 8d210b779442a5a9206702060aac67c1de4283186c0f167ebdb4488d149be872
* `FRED_MD/current.csv` 618fa325fdf4e2d8ec186050e064c99d53d2cfb8f331c4f3966c60b5e17334bd
* `FRED_MD/FRED-MD_updated_appendix.csv` 2c445e8918c615008b6df9f96f4c2b67b8ec592cab6728b49c04dfede9980d97
* `inflation/dataJBES.xlsx` 867be5abe6013162488dc5e4ad13110fd2cf42ed3564589c2e2658c307b739aa
* `inflation/Readme_dataJBES.rtf` a547bd7113cfe08a7b8deae7264204ba2f88526149073a4cc482acbe6668cd74
* `inflation/Supplement_GPR2013.pdf` 82cc857484842cc5713ee16e876b48f70f87c3e47c80882c0069355f232798a4
* `equity_premium/current_Index/README.md` 9e7c97d706cbcd9b3c8fd98ce1a7f93fd728d0ba87f5367cb9121b777b0d738c

## Datasets NOT included (and why)

* `edma/USData.csv` (found in the project workspace): an unrelated dataset, NOT the data of the paper's Table XI - excluded on purpose.
* Synthetic stand-in files used in earlier smoke tests of the loaders: random numbers, NOT data - excluded on purpose.
* UC-MA benchmark series / code (Chan 2013): not available.
* Datasets too large to package: none. The largest file is ~1.2 MB. (If you add a dataset larger than ~100 MB, keep it directly in Drive next to `datasets.zip` and extend `config.py`; see README.)
